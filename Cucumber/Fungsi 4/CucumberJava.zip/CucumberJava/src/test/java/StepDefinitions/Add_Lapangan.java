//package StepDefinitions;
//
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.WebElement;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//	public class Add_Lapangan {
//		WebDriver driver = null;
//		//Edit Lapangan
//		
//		//1
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Unavailable");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_product_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\module_table_bottom.png");
//		}
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement inputElement = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input"));
//			inputElement.clear();
//			inputElement.sendKeys("Lapangan 3");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement inputElement = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			inputElement.clear();
//			inputElement.sendKeys("mau dibuat");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_submit\"]")).click();
//		}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
//		//2
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Julitod");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("Pegatod");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////		3
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Julitod");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("Pegatod");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
//
//		
////		//4
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Julitod");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("Pegatod");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
/////		5
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("dsfsdfsdf");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("adasdaadsasd");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
//		//6
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("dwqesadasdasdf");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("acsdscdasaadas");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
////		7
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("dcqweqwasdf");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("aveqwqweasasaadas");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
////		8
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("casdasdasdas");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("aveqaadas");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
////// 		9
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("cqcwecqwewas");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("dasdasd");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
////		10		
////		@Given("browser is open")
////		public void browser_is_open() {
////		   System.out.println("Inside Step - browser is open");
////		   
////		   String projecPath = System.getProperty("user.dir");
////		   System.out.println("Project path is:"+projecPath);
////		   
////		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
////		   
////		   driver = new ChromeDriver();
////		   
////		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
////		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
////		}
////
////		@And("user is on login page")
////		public void user_is_on_login_page() {
////		    driver.navigate().to("http://127.0.0.1:8000/login/");
////		}
////
////		@When("user enters email and password")
////		public void user_enters_email_and_password() throws InterruptedException {
////		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
////		    driver.findElement(By.id("password")).sendKeys("password");
////		    Thread.sleep(2000);
////		    
////		}
////
////		@And("user click button login")
////		public void user_click_button_login() throws InterruptedException {
////		    driver.findElement(By.id("tombol_login")).click();
////		    Thread.sleep(2000);
////		}
////		
////		@Then("user confirm notification")
////		public void user_confirm_notification() {
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
////		}
////
////		@When("user is click menu Lapangan")
////		public void user_is_click_menu_Lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
////		}
////
////		@And("user click Add lapangan")
////		public void user_click_Add_lapangan() {
////			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
////		}
////
////		@When("user select status")
////		public void user_select_status() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
////		}
////		
////		@And("user add picture")
////		public void user_add_picture() {
////			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_avatar\"]"));
////			fileInput.sendKeys("C:\\xamppXD\\htdocs\\api_numero_sada\\public\\images\\lapangan\\77935040.jpg");
////		}
////	
////		@And("user enters Lapangan name")
////		public void user_enters_Lapangan_name() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("qwcepoqwkeqxwxwe");
////		}
////	
////		@And("user enters Description")
////		public void user_enters_Description() {
////		    driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea")).sendKeys("dasdasd");
////		}
////	
////		@And("user click button save changes")
////		public void user_click_button_save_changes() {
////			driver.findElement(By.id("kt_ecommerce_add_lapangan_submit")).click();
////		}
//	}