package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

	public class Edit_Lapangan {
		WebDriver driver = null;
		//Edit Lapangan	
		//1
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_product_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\module_table_bottom.png");
//		}
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("asdasdfasdadsf");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("uasiduadfdo");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		
		//2
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("Lapangan");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("sdfadf");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//3
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("!sdfadf#");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("fasdfsadf");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//4
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("!ladsfa");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//5
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("Lapangan baru");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("lapangan terbaru");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//6
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("lapangan terbaru");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//7
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("dlskafjlas");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//8
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Available");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("!sdfadf#");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//9
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\imgaes.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("hjsdfkas");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("ablasdfj");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//10
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("dsjfkhasdf");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("!sdfadf");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//11
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("asdfasdfa");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//12
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\images.jpeg");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("@");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("!#");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//13
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("lapangan lama");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("lapangan");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		//14
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("dsafasdf");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		
		//15
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("M0!");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("yasafdasdyf");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
		
		
		//16
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//		
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user is click menu Lapangan")
//		public void user_is_click_menu_Lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[3]/a/span[2]")).click();
//		}
//
//		@And("user click Edit lapangan")
//		public void user_click_Edit_lapangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/a")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_lapangan_table\"]/tbody/tr[1]/td[4]/div/div[1]/a")).click();
//		}
//		
//		@And("user edit status")
//		public void user_edit_status() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("asdf");
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//		
//		@And("user edit picture")
//		public void user_edit_picture() {
//			WebElement fileInput = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_avatar\"]"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\img\\no1.pdf");
//		}
//		
//		@And("user edit Lapangan name")
//		public void user_edit_Lapangan_name() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]"));
//			Input.clear();
//			Input.sendKeys("");
//		}
//	
//		@And("user edit Description")
//		public void user_edit_Description() {
//			WebElement Input = driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_edit_lapangan_form\"]/div[2]/div[1]/div[2]/div[2]/textarea"));
//			Input.clear();
//			Input.sendKeys("!sdfadf#");
//		}
//		
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.id("kt_ecommerce_edit_lapangan_submit")).click();
//		}
	}
