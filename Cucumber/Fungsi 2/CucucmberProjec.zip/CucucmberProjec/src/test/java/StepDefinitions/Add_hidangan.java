package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class Add_hidangan {
	WebDriver driver = null;
//test case 1
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("\"C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\96064249.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makanan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}

	//test case 2
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
////	@And("user enter Hidangan picture")
////	public void user_enter_Hidangan_picture() {
////		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("\"C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\96064249.jpg");
////	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("003");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makanan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 3
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\96064249.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("003");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 6
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\96064249.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 7
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\96064249.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 8
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 9
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 10
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Makan ringan");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 11
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("fqfqf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("10000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 12
//		@Given("browser is open")
//		public void browser_is_open() {
//		   System.out.println("Inside Step - browser is open");
//		   
//		   String projecPath = System.getProperty("user.dir");
//		   System.out.println("Project path is:"+projecPath);
//		   
//		   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//		   
//		   driver = new ChromeDriver();
//		   
//		   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//		   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		}
//
//		@And("user is on login page")
//		public void user_is_on_login_page() {
//		    driver.navigate().to("http://127.0.0.1:8000/login/");
//		}
//
//		@When("user enters email and password")
//		public void user_enters_email_and_password() throws InterruptedException {
//		    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//		    driver.findElement(By.id("password")).sendKeys("password");
//		    Thread.sleep(2000);
//		    
//		}
//
//		@And("user click button login")
//		public void user_click_button_login() throws InterruptedException {
//		    driver.findElement(By.id("tombol_login")).click();
//		    Thread.sleep(2000);
//		}
//
//		@Then("user confirm notification")
//		public void user_confirm_notification() {
//			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//		}
//
//		@When("user click menu Hidangan")
//		public void user_click_menu_Hidangan() {
//			driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//		}
//
//		@And("user click add Hidangan")
//		public void user_click_add_Hidangan() {
//			driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//		}
//
//		@When("user select category")
//		public void user_select_category() {
////			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////			driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//		}
//
//		@And("user enter Hidangan picture")
//		public void user_enter_Hidangan_picture() {
//			WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//			fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//		}
//
//		@And("user enter Hidangan name SKU Description Price Quantity")
//		public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("fqfqf");
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//		}
//
//		@And("user click button save changes")
//		public void user_click_button_save_changes() {
//			driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//		    throw new io.cucumber.java.PendingException();
//		}
	
//	//test case 14
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 15
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("qwdqwd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 16
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("qwdqwd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 18
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("qwdqwd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 19
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("11000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 20
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
////		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
////		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("12");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 21
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 22
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("10000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("31");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 23
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("31");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 24
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 25
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 26
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 27
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dafqdaw");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 28
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 29
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 30
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki	");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("afawfa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 30
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki	");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 31
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki	");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 32
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki	");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 33	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("006");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 34	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 35	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 36	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 37	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 38	
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 39
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 40
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 41
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 42
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 43
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 44
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 45
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 46
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 47
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 48
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awdawsc");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 49
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awdawsc");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 50
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("005");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 51
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("aawfawf");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 52
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 53
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 54
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("awdadwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 55
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 56
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 57
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 58
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 59
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 60
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 61
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan	");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("wdqdaw");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 62
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 63
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("Chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 64
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 65
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("002");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 66
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 66
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 67
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 68
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 69
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 70
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 71
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 72
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("dawdwa");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 73
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 74
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 75
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("wdawd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 75
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("wdawd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 76
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 77
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Minuman");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//	//	fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 78
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 79
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 80
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 81
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("asda");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 82
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("asda");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 83
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 84
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("ADDqd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 85
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("ADDqd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 86
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 87
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 88
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("Dadawd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 89
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 90
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Makanan");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 91
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 92
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("wdqwd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 93
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("wdqwd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 94
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 95
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 96
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 97
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
////		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 98
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("adawd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("11");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
//	//test case 99
//	@Given("browser is open")
//	public void browser_is_open() {
//	   System.out.println("Inside Step - browser is open");
//	   
//	   String projecPath = System.getProperty("user.dir");
//	   System.out.println("Project path is:"+projecPath);
//	   
//	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
//	   
//	   driver = new ChromeDriver();
//	   
//	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
//	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    driver.navigate().to("http://127.0.0.1:8000/login/");
//	}
//
//	@When("user enters email and password")
//	public void user_enters_email_and_password() throws InterruptedException {
//	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
//	    driver.findElement(By.id("password")).sendKeys("password");
//	    Thread.sleep(2000);
//	    
//	}
//
//	@And("user click button login")
//	public void user_click_button_login() throws InterruptedException {
//	    driver.findElement(By.id("tombol_login")).click();
//	    Thread.sleep(2000);
//	}
//
//	@Then("user confirm notification")
//	public void user_confirm_notification() {
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
//	}
//
//	@When("user click menu Hidangan")
//	public void user_click_menu_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
//	}
//
//	@And("user click add Hidangan")
//	public void user_click_add_Hidangan() {
//		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
//	}
//
//	@When("user select category")
//	public void user_select_category() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Minuman");
//		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
//	}
//
//	@And("user enter Hidangan picture")
//	public void user_enter_Hidangan_picture() {
//		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
//		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
//	}
//
//	@And("user enter Hidangan name SKU Description Price Quantity")
//	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("chiki");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("adawd");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");
//
//	}
//
//	@And("user click button save changes")
//	public void user_click_button_save_changes() {
//		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
//	    throw new io.cucumber.java.PendingException();
//	}
	
	//test case 100
	@Given("browser is open")
	public void browser_is_open() {
	   System.out.println("Inside Step - browser is open");
	   
	   String projecPath = System.getProperty("user.dir");
	   System.out.println("Project path is:"+projecPath);
	   
	   System.setProperty("webdriver.chrome.driver", projecPath+"/src/test/resources/drivers/chromedriver.exe");
	   
	   driver = new ChromeDriver();
	   
	   driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	   driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	}

	@And("user is on login page")
	public void user_is_on_login_page() {
	    driver.navigate().to("http://127.0.0.1:8000/login/");
	}

	@When("user enters email and password")
	public void user_enters_email_and_password() throws InterruptedException {
	    driver.findElement(By.id("email")).sendKeys("admin@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("password");
	    Thread.sleep(2000);
	    
	}

	@And("user click button login")
	public void user_click_button_login() throws InterruptedException {
	    driver.findElement(By.id("tombol_login")).click();
	    Thread.sleep(2000);
	}

	@Then("user confirm notification")
	public void user_confirm_notification() {
		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/div[2]/div/div[6]/button[1]")).click();
	}

	@When("user click menu Hidangan")
	public void user_click_menu_Hidangan() {
		driver.findElement(By.xpath("//*[@id=\"#kt_aside_menu\"]/div[2]/a")).click();
	}

	@And("user click add Hidangan")
	public void user_click_add_Hidangan() {
		driver.findElement(By.xpath("//*[@id=\"kt_content_container\"]/div/div[1]/div[2]/a")).click();
	}

	@When("user select category")
	public void user_select_category() {
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[1]/div/div[2]/span/span[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys("Minuman");
		driver.findElement(By.xpath("//*[@id=\"kt_body\"]/span/span/span[1]/input")).sendKeys(Keys.ENTER);
	}

	@And("user enter Hidangan picture")
	public void user_enter_Hidangan_picture() {
		WebElement fileInput = driver.findElement(By.id("kt_ecommerce_add_product_avatar"));
		fileInput.sendKeys("C:\\xampp\\htdocs\\api_numero_sada\\public\\images\\products\\295659275.jpg");
	}

	@And("user enter Hidangan name SKU Description Price Quantity")
	public void user_enter_Hidangan_name_SKU_Description_Price_Quantity() {
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[1]/input[2]")).sendKeys("");
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[2]/input")).sendKeys("001");
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[3]/textarea")).sendKeys("adawd");
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("1000");
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_form\"]/div[2]/div[1]/div[2]/div[5]/input")).sendKeys("");

	}

	@And("user click button save changes")
	public void user_click_button_save_changes() {
		driver.findElement(By.xpath("//*[@id=\"kt_ecommerce_add_product_submit\"]")).click();
	    throw new io.cucumber.java.PendingException();
	}
}